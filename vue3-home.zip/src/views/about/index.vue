<script setup>
import {ref,onMounted} from 'vue'
import WOW from 'wow.js'
import axios from 'axios'
let n = ref(0);
let joinlist = ref();
let aboutlist = ref();

onMounted(async()=>{
 var wow = new WOW({
    boxClass: 'wow', // 需要执行动画的元素的 class; 【String类型】默认值：‘wow'；
    animateClass: 'animated', // animation.css 动画的 class; 【String类型】默认值：‘animated'；
    offset: 0, // 距离可视区域多少开始执行动画；【整数Number类型】默认值：0；
    mobile: true, // 是否在移动设备上执行动画；【Boolean类型】默认值: true;
    live: true // 异步加载的内容是否有效；【Boolean类型】默认值: true;
    });
 wow.init();
  let res = await axios.get('http://127.0.0.1:7003/api/joinlist'); //请求地址
  joinlist.value = res.data;
   let res1 = await axios.get('http://127.0.0.1:7003/api/aboutlist'); //请求地址
  aboutlist.value = res1.data;
})

function action(i) {
    n.value = i
}
</script>

<template>
  <div class="container">
    <div class="about">
      <div class="about-faith mt-50">
        <h3 class="about-title wow fadeInDown">诚信经营 值得信赖</h3>
        <p class="about-subtitle wow fadeInUp">荣获政府单位、行业协会、官方媒体的多重认可</p>
        <ul class="wow bounceIn">
          <li class="box1">
            <p>
              <span>中国中高档装修领军品牌</span>
            </p>
          </li>
          <li class="box2">
            <p>
              <span>中国中高档装修领军品牌</span>
            </p>
          </li>
          <li class="box3">
            <p>
              <span>中国中高档装修领军品牌</span>
            </p>
          </li>
          <li class="box4">
            <p>
              <span>中国中高档装修领军品牌</span>
            </p>
          </li>
          <li class="box5">
            <p>
              <span>中国中高档装修领军品牌</span>
            </p>
          </li>
          <li class="box6">
            <p>
              <span>中国中高档装修领军品牌</span>
            </p>
          </li>
          <li class="box7">
            <p>
              <span>中国中高档装修领军品牌</span>
            </p>
          </li>
        </ul>
      </div>
      <div class="about-leading mt-50">
        <h3 class="about-title wow fadeInDown">金钻工程 领跑行业</h3>
        <p class="about-subtitle wow fadeInUp">匠心沉淀 手工活标准化</p>
        <!-- <ul>
                <li @click="n=1">点击的第一个模块</li>
                <li @click="n=2">点击的第二个模块</li>
                <li @click="n=3">点击的第三个模块</li>
                <li @click="n=4">点击的第四个模块</li>
                <li @click="n=5">点击的第五个模块</li>
                <li @click="n=6">点击的第六个模块</li>
            </ul>
            <div>
                <p v-show="n==1">这是显示的第一个图片</p>
                <p v-show="n==2">这是显示的第二个图片</p>
                <p v-show="n==3">这是显示的第三个图片</p>
                <p v-show="n==4">这是显示的第四个图片</p>
                <p v-show="n==5">这是显示的第五个图片</p>
                <p v-show="n==6">这是显示的第六个图片</p>
            </div> -->
        <ul>
          <li
            v-for="(v, i) in aboutlist"
            :key="i"
            :class="n == i ? 'selected' : ''"
            @click="action(i)"
          >
            {{ v.title }}
          </li>
        </ul>
        <div class="img-show">
          <img
            v-for="(v, i) in aboutlist"
            :key="i"
            v-show="n == i"
            :src="v.img_url"
            alt=""
          />
        </div>
      </div>
      <div class="about-jin mt-50">
        <h3 class="about-title wow fadeInDown">招商加盟</h3>
        <p class="about-subtitle wow fadeInDown">INVESTMENT TO JOIN</p>
        <ul>
            <li v-for="(v,i) in joinlist" :key="i">
              <img :src="v.img_url" alt="" class="wow fadeInLeft">
              <span class="btit">{{v.title}}</span>
            </li>
          </ul>
      </div>
    </div>
  </div>
</template>

<style scoped>
</style>


