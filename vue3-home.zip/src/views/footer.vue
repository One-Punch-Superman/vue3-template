<script setup>
import {ref,onMounted} from 'vue'
import axios from 'axios'
let footerlist = ref()

onMounted(async()=>{
  let res = await axios.get('http://127.0.0.1:7003/api/footerlist'); //请求地址
  footerlist.value = res.data;
});
</script>

<template>
    <div class="footer">
        <div class="footer-list">
            <div class="footer-left">
                <ul>
                    <li v-for="(v,i) in footerlist" :key="i">
                        <p>{{v.title}}</p>
                        <a href="#" v-for="(item,i) in v.list" :key="i">{{item}}</a>
                    </li>
                </ul>
            </div>
            <div class="footer-map"></div>
        </div>
    </div>

</template>

<style scoped>

</style>


