<template>
  <Banner />
  <div class="container">
    <div class="house-tabs mt-50">
      <div class="house-title">全屋设计案例，给你更多建议</div>
      <div class="house-sub">多元家居风格，给你更多选择</div>
      <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
        <el-tab-pane
          :label="v.label"
          :name="v.id"
          v-for="(v, i) in housetabs"
          :key="i"
        >
          <ul>
            <li v-for="(item, i) in v.tabs" :key="i">
              <img :src="`/src/assets/images/${item.img_url}`" alt="" />
              <p>{{ item.title }}</p>
            </li>
          </ul>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div class="house-grid mt-50">
      <div class="house-title">全屋设计案例，给你更多建议</div>
      <div class="house-sub">多元家居风格，给你更多选择</div>
      <ul>
        <li class="li1"><img src="@/assets/images/house1.png" alt="" /></li>
        <li class="li2"><img src="@/assets/images/house2.png" alt="" /></li>
        <li class="li3"><img src="@/assets/images/house3.png" alt="" /></li>
        <li class="li4"><img src="@/assets/images/house4.png" alt="" /></li>
        <li class="li5"><img src="@/assets/images/house5.png" alt="" /></li>
      </ul>
    </div>
    <div class="house-carousel mt-50 mb-50">
      <el-carousel indicator-position="none" arrow="always" :autoplay="false">
        <el-carousel-item>
          <img src="@/assets/images/10.png" alt="" />
          <img src="@/assets/images/10.png" alt="" />
          <img src="@/assets/images/10.png" alt="" />
          <img src="@/assets/images/10.png" alt="" />
        </el-carousel-item>
        <el-carousel-item>
          <img src="@/assets/images/11.png" alt="" />
          <img src="@/assets/images/11.png" alt="" />
          <img src="@/assets/images/11.png" alt="" />
          <img src="@/assets/images/11.png" alt="" />
        </el-carousel-item>
        <el-carousel-item>
          <img src="@/assets/images/10.png" alt="" />
          <img src="@/assets/images/10.png" alt="" />
          <img src="@/assets/images/11.png" alt="" />
          <img src="@/assets/images/11.png" alt="" />
        </el-carousel-item>
      </el-carousel>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import Banner from "../index/banner.vue";

let activeName = ref(1);
let housetabs = ref([
  {
    id: 1,
    label: "三室二厅",
    tabs: [
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
    ],
  },
  {
    id: 2,
    label: "二室二厅",
    tabs: [
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "11.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "11.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "11.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "11.png" },
    ],
  },
  {
    id: 3,
    label: "一室一厅",
    tabs: [
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
      { title: "建筑面积：97m2 | 多功能的温馨之家", img_url: "10.png" },
    ],
  },
]);
</script>

<style scoped>
.house-title {
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 10px;
}
.house-sub {
  font-weight: 700;
  font-size: 12px;
  margin-bottom: 10px;
}
.house-tabs ul {
  display: flex;
  justify-content: space-between;
}
.house-tabs ul li img {
  width: 100%;
  height: 230px;
  object-fit: cover;
}
.house-tabs ul li p {
  font-weight: 700;
  margin-top: 10px;
}
.house-grid ul {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 20px;
  grid-template-areas:
    "li1 li1 li1 li1 li1 li1 li3 li3 li3 li4 li4 li4"
    "li1 li1 li1 li1 li1 li1 li2 li2 li2 li4 li4 li4"
    "li1 li1 li1 li1 li1 li1 li2 li2 li2 li4 li4 li4"
    "li1 li1 li1 li1 li1 li1 li2 li2 li2 li4 li4 li4"
    "li1 li1 li1 li1 li1 li1 li2 li2 li2 li5 li5 li5"
    "li1 li1 li1 li1 li1 li1 li2 li2 li2 li5 li5 li5";
}
.li1 {
  grid-area: li1;
}
.li2 {
  grid-area: li2;
}
.li3 {
  grid-area: li3;
}
.li4 {
  grid-area: li4;
}
.li5 {
  grid-area: li5;
}
.house-grid ul img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.house-carousel img {
  width: calc(100% / 4 - 20px);
  margin: 0 10px;
  height: 280px;
  object-fit: cover;
}
.house-carousel .el-carousel__arrow i {
  font-size: 30px;
}
</style>
