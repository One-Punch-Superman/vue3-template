import { createRouter,createWebHashHistory } from "vue-router"

const routes =[
    {
        path:'/',      //首页
        redirect:'/index'
    },
    {
        path:'/index',      //首页
        name:'index',  
        component:()=>import('../views/index/index.vue')
    },
    {
        path:'/house',      //全屋设计
        name:'house',  
        component:()=>import('../views/house/index.vue')
    },
    {
        path:'/kitchen',      //厨房设计
        name:'kitchen',  
        component:()=>import('../views/kitchen/index.vue')
    },
    {
        path:'/collocation',      //家居搭配
        name:'collocation',  
        component:()=>import('../views/collocation/index.vue')
    },
    {
        path:'/case',      //设计案例
        name:'case',  
        component:()=>import('../views/case/index.vue')
    },
    {
        path:'/about',      //关于我们
        name:'about',  
        component:()=>import('../views/about/index.vue')
    },
]

const router = createRouter ({
    history: createWebHashHistory(),
    routes
})
export default router