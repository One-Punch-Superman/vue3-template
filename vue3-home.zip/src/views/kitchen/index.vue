<script setup>
import {ref} from 'vue'

</script>

<template>
    <div>
       厨房设计
    </div>

</template>

<style scoped>

</style>


