<script setup>
import {ref} from 'vue'

</script>

<template>
    <div>
      家居搭配
    </div>

</template>

<style scoped>

</style>


