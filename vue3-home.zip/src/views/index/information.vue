<template>
  <!-- 家装资讯 -->
  <div class="container_bg">
    <div class="information">
      <div class="index_title">
        <h3>家装资讯</h3>
        <p>了解装修知识 装修不留遗憾</p>
      </div>
      <div class="information-list">
        <div class="information-left">
          <el-carousel height="380px" indicator-position="none" arrow="always">
            <el-carousel-item v-for="(v, i) in informationimg" :key="i">
              <img :src="`/src/assets/images/${v.img_url}`" alt="" />
            </el-carousel-item>
          </el-carousel>
        </div>
        <div class="information-right">
          <ul>
            <li v-for="(v, i) in informationlist" :key="i">
              <div class="information-r-img">
                <img :src="`/src/assets/images/${v.img_url}`" alt="" />
              </div>
              <div class="information-r-list">
                <p class="information-tit">{{ v.title }}</p>
                <p class="information-time">{{ v.date }}</p>
                <p class="information-desc">{{ v.subtitle }}</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";

let informationimg = ref([
  {
    id: 1,
    img_url: "10.png",
  },
  {
    id: 1,
    img_url: "11.png",
  },
  {
    id: 1,
    img_url: "10.png",
  },
]);
let informationlist = ref([
  {
    title: "如何辨别实木地板的色差",
    subtitle:
      "消费者在购买地板时，往往发现地板的颜色存在差异，即俗称色差。而色差往往成为消费者与商家产生争议的焦点，而在购买时如何避免这个问题呢？",
    date: "2024-03-08",
    img_url: "10.png",
  },
  {
    title: "如何辨别实木地板的色差",
    subtitle:
      "消费者在购买地板时，往往发现地板的颜色存在差异，即俗称色差。而色差往往成为消费者与商家产生争议的焦点，而在购买时如何避免这个问题呢？",
    date: "2024-03-08",
    img_url: "10.png",
  },
  {
    title: "如何辨别实木地板的色差",
    subtitle:
      "消费者在购买地板时，往往发现地板的颜色存在差异，即俗称色差。而色差往往成为消费者与商家产生争议的焦点，而在购买时如何避免这个问题呢？",
    date: "2024-03-08",
    img_url: "10.png",
  },
]);
</script>

<style scoped>
/* 家装资讯 */

.information-list {
  display: flex;
  height: 380px;
  gap: 0 30px;
}
.information-left {
  width: 40%;
}
.information-right {
  width: 60%;
}
.information-right ul {
  width: 100%;
  height: 380px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 20px;
}
.information-right ul li {
  display: flex;
  gap: 0 20px;
  height: calc(380px / 3 - 20px);
}
.information-r-img {
  width: 170px;
  flex-shrink: 0;
}
.information-right ul li img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.information-tit {
  font-size: 16px;
}
.information-time {
  color: #999;
  margin-top: 10px;
}
.information-desc {
  color: #666;
  margin-top: 10px;
}
</style>
